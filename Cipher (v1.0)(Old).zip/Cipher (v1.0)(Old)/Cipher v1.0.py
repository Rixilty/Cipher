import time

def Main_Menu():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num
    
    Choice = input("Do you want to Enrcrypt(E), or Decrypt(D): ").lower()

    Non_Encrypted_List = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_", "+", "=", "[", "]", "{", "}", "|", "\\", ";", ":", ",", ".", "<", ">", "/", "?", "`"]    
    Encrypted_List = ['|', 'n', ']', '$', '!', 'y', '=', '/', 'q', '8', 'c', 'w', 'g', '^', '4', '@', '&', 't', '}', 'u', ':', '1', '?', '2', 's', 'l', '\\', '<', '6', 'b', '(', '>', 'o', 'h', 'j', '.', 'z', '-', 'k', '`', '5', '%', 'i', '[', '_', '0', 'r', 'v', 'f', 'd', 'p', '9', ',', ';', '3', '+', 'm', 'a', '*', ')', '7', 'e', '#', 'x', '{']

    Num = 0
    Current_Character = 0
    
    if Choice == "e":
        Text = input("Enter the text you want to encrypt: ").lower()
        Text_Length = len(Text)
        Encrypter()
    elif Choice == "d":
        Text = input("Enter the text you want to decrypt: ").lower()
        Text_Length = len(Text)
        Decrypter()
    else:
        Main_Menu()
        

def Encrypter():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num
    
    Encrypted_Text = ""
    
    for i in range(Text_Length):
        Num = 0
        found_match = False
        while not found_match and Num < len(Non_Encrypted_List):
            if Text[Current_Character] == Non_Encrypted_List[Num]:
                Encrypted_Text += Encrypted_List[Num]
                Current_Character += 1
                found_match = True
            else:
                Num += 1
                
        if not found_match:
            Encrypted_Text += Text[Current_Character]
            Current_Character += 1

    Cipher = "Encrypting text"      

    print(Cipher, end="")
    for i in range(3):
        print(".", end="")
        time.sleep(1.2)
    print()
    
    print("Encrypted Text: ", Encrypted_Text)

    print()
    print("--")
    Main_Menu()

def Decrypter():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num
    
    Decrypted_Text = ""
    
    for i in range(Text_Length):
        Num = 0
        found_match = False
        while not found_match and Num < len(Non_Encrypted_List):
            if Text[Current_Character] == Encrypted_List[Num]:
                Decrypted_Text += Non_Encrypted_List[Num]
                Current_Character += 1
                found_match = True
            else:
                Num += 1
                
        if not found_match:
            Decrypted_Text += Text[Current_Character]
            Current_Character += 1

    Cipher = "Decrypting text"        

    print(Cipher, end="")
    for i in range(3):
        print(".", end="")
        time.sleep(1.2)
    print()     
            
    print("Decrypted Text: ", Decrypted_Text)

    print()
    print("--")
    Main_Menu()

Main_Menu()

