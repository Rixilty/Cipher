import time

version = "v1.0"

import time

def display_text(text):
    for letter in text:
        print(letter, end='', flush=True)
        time.sleep(0.03)
        
def display_text2(text2):
    for letter2 in text2:
        print(letter2, end='', flush=True)
        time.sleep(0.03)

with open ("Note.txt", "r+") as f:
    файл = f.read()

    if "True" in файл:
        display_text("NOTE! You're currently using an old version of cipher (current version: " + version + ") and should consider upgrading to the latest version for better security and encryption/decryption methods!\nTry checking your zip file since the latest version should be included in there.\n")

        признанный = input("Please indicate your acknowledgement by typing (OK) in all uppercase letters: ")
        if признанный == "OK":
            display_text2("you will only see this warning once\n")
            подтверждать = input("Press (Enter) to continue: ")
            файл = файл.replace("True", "False")
            f.seek(0)
            f.write(файл)
            f.truncate()
        else:
            print("Error!")
            признанный = input("Please type (OK) all uppercase to indicare your acknowledgement: ")

            
def Main_Menu():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num
    
    Choice = input("Do you want to Enrcrypt(E), or Decrypt(D): ").lower()

    Non_Encrypted_List = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_", "+", "=", "[", "]", "{", "}", "|", "\\", ";", ":", ",", ".", "<", ">", "/", "?", "`"]    
    Encrypted_List = ['|', 'n', ']', '$', '!', 'y', '=', '/', 'q', '8', 'c', 'w', 'g', '^', '4', '@', '&', 't', '}', 'u', ':', '1', '?', '2', 's', 'l', '\\', '<', '6', 'b', '(', '>', 'o', 'h', 'j', '.', 'z', '-', 'k', '`', '5', '%', 'i', '[', '_', '0', 'r', 'v', 'f', 'd', 'p', '9', ',', ';', '3', '+', 'm', 'a', '*', ')', '7', 'e', '#', 'x', '{']

    Num = 0
    Current_Character = 0
    
    if Choice == "e":
        Text = input("Enter the text you want to encrypt: ").lower()
        Text_Length = len(Text)
        Encrypter()
    elif Choice == "d":
        Text = input("Enter the text you want to decrypt: ").lower()
        Text_Length = len(Text)
        Decrypter()
    else:
        Main_Menu()
        

def Encrypter():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num
    
    Encrypted_Text = ""
    
    for i in range(Text_Length):
        Num = 0
        found_match = False
        while not found_match and Num < len(Non_Encrypted_List):
            if Text[Current_Character] == Non_Encrypted_List[Num]:
                Encrypted_Text += Encrypted_List[Num]
                Current_Character += 1
                found_match = True
            else:
                Num += 1
                
        if not found_match:
            Encrypted_Text += Text[Current_Character]
            Current_Character += 1

    Cipher = "Encrypting text"      

    print(Cipher, end="")
    for i in range(3):
        print(".", end="")
        time.sleep(1.2)
    print()
    
    print("Encrypted Text: ", Encrypted_Text)

    print()
    print("--")
    Main_Menu()

def Decrypter():
    global Text, Text_Length, Current_Character, Non_Encrypted_List, Encrypted_List, Num
    
    Decrypted_Text = ""
    
    for i in range(Text_Length):
        Num = 0
        found_match = False
        while not found_match and Num < len(Non_Encrypted_List):
            if Text[Current_Character] == Encrypted_List[Num]:
                Decrypted_Text += Non_Encrypted_List[Num]
                Current_Character += 1
                found_match = True
            else:
                Num += 1
                
        if not found_match:
            Decrypted_Text += Text[Current_Character]
            Current_Character += 1

    Cipher = "Decrypting text"        

    print(Cipher, end="")
    for i in range(3):
        print(".", end="")
        time.sleep(1.2)
    print()     
            
    print("Decrypted Text: ", Decrypted_Text)

    print()
    print("--")
    Main_Menu()

Main_Menu()

